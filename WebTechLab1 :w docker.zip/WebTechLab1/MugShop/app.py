from flask import Flask, request, g
from flask_login import LoginManager
from flask_caching import Cache
import time
from collections import deque
import os
from models import db

# Инициализация приложения
app = Flask(__name__)

# Конфигурация из переменных окружения
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL', 'sqlite:///site.db'
)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-123')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Настройка кеширования
app.config.update({
    'CACHE_TYPE': 'simple',
    'CACHE_DEFAULT_TIMEOUT': 60
})
cache = Cache(app)

# Инициализация базы данных
db.init_app(app)

# Настройка Flask-Login
login_manager = LoginManager(app)


@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))


# Лог запросов и замеры времени
request_log = deque(maxlen=50)


@app.before_request
def start_timer():
    g.start = time.time()


@app.after_request
def log_and_set_cache_headers(response):
    if hasattr(g, 'start'):
        duration = time.time() - g.start
        request_log.appendleft({'path': request.path, 'time': duration})
        print(f"[TIME] {request.path} — {duration:.4f}s")

    if request.path.startswith('/static/'):
        response.cache_control.public = True
        response.cache_control.max_age = 86400

    return response


def initialize_database():
    """Инициализация базы данных и создание администратора"""
    with app.app_context():
        db.create_all()
        from models import User
        if not User.query.first():
            from werkzeug.security import generate_password_hash
            admin = User(
                username='admin',
                password=generate_password_hash('123')
            )
            db.session.add(admin)
            db.session.commit()
            print("✅ Создан администратор: admin/123")


# Импорт маршрутов должен быть после создания app
# Это предотвращает циклические импорты
from routes import *

if __name__ == '__main__':
    # Определяем порт из переменных окружения
    port = int(os.environ.get('PORT', 5001))

    # Проверяем, запущено ли в контейнере
    in_container = "DATABASE_URL" in os.environ

    if in_container:
        # В контейнере: запускаем на нужном порту
        print(f"🚀 Запуск в контейнере на порту {port}")
        app.run(host='0.0.0.0', port=port)
    else:
        # Локальный запуск: инициализация и дебаг
        print("💻 Локальный запуск (режим отладки)")
        initialize_database()
        app.run(debug=True, host='0.0.0.0', port=port)